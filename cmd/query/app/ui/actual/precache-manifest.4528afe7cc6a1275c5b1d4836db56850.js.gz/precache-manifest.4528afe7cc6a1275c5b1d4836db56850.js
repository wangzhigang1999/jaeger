self.__precacheManifest = [
  {
    "revision": "7827216ab8e895557aa4",
    "url": "./static/css/main.10e081dd.chunk.css"
  },
  {
    "revision": "7827216ab8e895557aa4",
    "url": "./static/js/main.7827216a.chunk.js"
  },
  {
    "revision": "046d026e880212e228af",
    "url": "./static/css/1.c8bfc608.chunk.css"
  },
  {
    "revision": "046d026e880212e228af",
    "url": "./static/js/1.046d026e.chunk.js"
  },
  {
    "revision": "4a686d48d5a089750c49",
    "url": "./static/js/runtime~main.4a686d48.js"
  },
  {
    "revision": "a7093b12e8a9970b9e82a97dd39d12cc",
    "url": "./static/media/jaeger-logo.a7093b12.svg"
  },
  {
    "revision": "c9164c967f4881884753564e6b02c492",
    "url": "./static/media/monitor.c9164c96.png"
  },
  {
    "revision": "163a96eb4659665392af429939295fa7",
    "url": "./index.html"
  }
];